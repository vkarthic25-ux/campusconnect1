import React, { useEffect, useState } from 'react';
import { FaBullhorn, FaPlus, FaTrash, FaEdit, FaTimes } from 'react-icons/fa';
import API from '../services/api';
import { useAuth } from '../context/AuthContext';
import PageHeader from '../components/common/PageHeader';
import Modal from '../components/common/Modal';

const initialForm = { title: '', content: '', priority: 'normal' };

export default function Announcements() {
  const { user } = useAuth();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const canCreate = ['super_admin', 'faculty', 'club_admin'].includes(user?.role);

  const load = async () => {
    setLoading(true);
    setError('');
    try {
      const r = await API.get('/announcements');
      setData(r.data?.data || []);
    } catch (e) {
      setError(e.response?.data?.message || 'Unable to load announcements. Please check that the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const closeModal = () => {
    setOpen(false);
    setEditing(null);
    setForm(initialForm);
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      if (editing) await API.put(`/announcements/${editing._id}`, form);
      else await API.post('/announcements', form);
      closeModal();
      await load();
    } catch (e) {
      setError(e.response?.data?.message || 'Unable to save announcement.');
    } finally {
      setSaving(false);
    }
  };

  const del = async (id) => {
    if (!window.confirm('Delete this announcement?')) return;
    try {
      await API.delete(`/announcements/${id}`);
      await load();
    } catch (e) {
      setError(e.response?.data?.message || 'Unable to delete announcement.');
    }
  };

  const edit = (a) => {
    setEditing(a);
    setForm({ title: a.title || '', content: a.content || '', priority: a.priority || 'normal' });
    setOpen(true);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Campus Announcements"
        description="Important KIOT notices, club updates and community messages in one place."
        buttonText={canCreate ? 'New Announcement' : undefined}
        onClick={() => { setEditing(null); setForm(initialForm); setOpen(true); }}
      />

      {error && (
        <div className="flex items-center justify-between rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
          <span>{error}</span>
          <button onClick={() => setError('')}><FaTimes /></button>
        </div>
      )}

      {loading ? (
        <div className="rounded-2xl bg-white p-10 text-center font-bold text-slate-500 shadow-sm">Loading announcements...</div>
      ) : data.length ? (
        <div className="grid gap-5 lg:grid-cols-2">
          {data.map((a, index) => (
            <article key={a._id} className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl">
              <div className="relative h-36 overflow-hidden">
                <img
                  src={index % 2 === 0 ? '/assets/kiot-banner.jpg' : '/assets/event-innovation.svg'}
                  alt="KIOT announcement"
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-blue-950/80 via-blue-700/30 to-transparent" />
                <div className="absolute left-5 top-5 flex h-11 w-11 items-center justify-center rounded-xl bg-white text-blue-700 shadow-lg"><FaBullhorn /></div>
                <span className={`absolute right-4 top-4 rounded-full px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide ${a.priority === 'high' ? 'bg-red-500 text-white' : a.priority === 'low' ? 'bg-emerald-500 text-white' : 'bg-blue-500 text-white'}`}>
                  {a.priority || 'normal'}
                </span>
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <h2 className="text-xl font-black tracking-tight text-slate-900">{a.title}</h2>
                  {canCreate && (a.createdBy?._id === user?._id || user?.role === 'super_admin') && (
                    <div className="flex shrink-0 gap-1">
                      <button onClick={() => edit(a)} className="rounded-lg p-2 text-slate-400 hover:bg-blue-50 hover:text-blue-600"><FaEdit /></button>
                      <button onClick={() => del(a._id)} className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"><FaTrash /></button>
                    </div>
                  )}
                </div>
                <p className="mt-3 whitespace-pre-line text-sm font-medium leading-6 text-slate-600">{a.content}</p>
                <p className="mt-4 border-t border-slate-100 pt-3 text-xs font-bold text-slate-400">
                  Posted by {a.createdBy?.name || 'KIOT Admin'} • {a.createdAt ? new Date(a.createdAt).toLocaleDateString() : 'Recently'}
                </p>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border-2 border-dashed border-slate-200 bg-white p-12 text-center font-bold text-slate-500">No announcements yet.</div>
      )}

      <Modal open={open} onClose={closeModal} title={editing ? 'Edit Announcement' : 'New Announcement'}>
        <form onSubmit={submit} className="space-y-4">
          <Field label="Title" value={form.title} onChange={v => setForm({ ...form, title: v })} required />
          <Field label="Message" value={form.content} onChange={v => setForm({ ...form, content: v })} textarea required />
          <label className="block">
            <span className="mb-1.5 block text-sm font-extrabold">Priority</span>
            <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold outline-none focus:border-blue-500">
              <option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option>
            </select>
          </label>
          <button disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 font-extrabold text-white transition hover:bg-blue-700 disabled:opacity-60">
            <FaPlus /> {saving ? 'Saving...' : editing ? 'Update Announcement' : 'Publish Announcement'}
          </button>
        </form>
      </Modal>
    </div>
  );
}

function Field({ label, value, onChange, textarea, required }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-extrabold">{label}</span>{textarea ? <textarea required={required} rows="5" value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-medium outline-none focus:border-blue-500" /> : <input required={required} value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-medium outline-none focus:border-blue-500" />}</label>;
}
