# CampusConnect – KIOT College Community Portal

CampusConnect is a full-stack college community portal for students, faculty, club administrators and super administrators.

## Fixed and Enhanced Features

- Student profile with Student ID, phone, department, year, bio, interests and skills
- Achievement creation, viewing and deletion with error handling
- Community discussions with comments, delete-own-discussion and error states
- Notification center with read/unread filters and mark-all-read
- Super Admin user management with role editing, activation/deactivation and deletion
- Club discovery search and category filters
- Club membership form that collects student ID, phone, department, year, interests and reason for joining
- Club member details stored in MongoDB
- Event discovery search and category filters
- Event registration form that collects participant name, email, phone, student ID, department, year and purpose
- Event registration details stored in MongoDB
- Registration confirmation prevents duplicate registration
- Organizer event details modal with participant registration responses
- Real notifications are generated when a user joins a club or registers for an event
- Fixed user identity handling by exposing both `_id` and `id` in authentication responses
- Safer user-management API access: only Super Admin can list users
- Responsive modern UI with search, filters, modals, cards and status states

## Technology

### Frontend
React, React Router, Tailwind CSS, Axios, React Icons, Socket.IO Client

### Backend
Node.js, Express.js, Mongoose, JWT, bcryptjs

### Database
MongoDB / MongoDB Atlas

## Project Structure

```text
CampusConnect/
├── client/
│   └── src/
└── server/
    ├── controllers/
    ├── models/
    ├── routes/
    └── middleware/
```

## Run Locally

### 1. MongoDB

Start local MongoDB or use MongoDB Atlas.

### 2. Server

```bash
cd server
npm install
npm run seed
npm start
```

The API runs on:

```text
http://localhost:5000
```

### 3. Client

```bash
cd client
npm install
npm run dev
```

The frontend runs on:

```text
http://localhost:5173
```

## Demo Accounts

| Role | Email | Password |
|---|---|---|
| Super Admin | admin@kiot.ac.in | Admin@123 |
| Faculty | faculty@kiot.ac.in | Faculty@123 |
| Club Admin | clubadmin@kiot.ac.in | ClubAdmin@123 |
| Student | student@kiot.ac.in | Student@123 |

## Important

For a production deployment, change the JWT secret and use environment variables for all database credentials and API keys.
