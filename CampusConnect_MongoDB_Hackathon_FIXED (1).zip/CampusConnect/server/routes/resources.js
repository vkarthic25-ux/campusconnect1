import { Router } from 'express';
import { list, getOne, create, update, remove, stats, joinClub, registerEvent, addComment } from '../controllers/crudController.js';
import { protect } from '../middleware/auth.js';

const r = Router();
const allowedResources = ['achievements', 'clubs', 'events', 'announcements', 'discussions', 'users'];

const resourceGuard = (req, res, next) => {
  if (!allowedResources.includes(req.params.resource)) {
    return res.status(404).json({ success: false, message: 'Resource not found' });
  }
  next();
};

// Action routes must come before /:resource/:id.
r.post('/clubs/:id/join', protect, joinClub);
r.post('/events/:id/register', protect, registerEvent);
r.post('/discussions/:id/comments', protect, addComment);
r.get('/dashboard/stats', protect, stats);

// Generic CRUD routes.
r.get('/:resource', protect, resourceGuard, list);
r.get('/:resource/:id', protect, resourceGuard, getOne);
r.post('/:resource', protect, resourceGuard, create);
r.put('/:resource/:id', protect, resourceGuard, update);
r.delete('/:resource/:id', protect, resourceGuard, remove);

export default r;
