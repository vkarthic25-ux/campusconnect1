import User from '../models/User.js';
export async function getMe(req,res){const user=await User.findById(req.user._id).select('-password');res.json({data:user});}
export async function updateMe(req,res){try{
  const allowed=['name','phone','studentId','department','year','profileImage','bio','interests','skills'];
  const body={};
  for(const k of allowed)if(req.body[k]!==undefined)body[k]=req.body[k];
  for(const k of ['interests','skills'])if(typeof body[k]==='string')body[k]=body[k].split(',').map(x=>x.trim()).filter(Boolean);
  const user=await User.findByIdAndUpdate(req.user._id,body,{new:true,runValidators:true}).select('-password');
  res.json({message:'Profile updated successfully',data:user});
}catch(e){res.status(400).json({message:e.message});}}
