import Notification from '../models/Notification.js';
export async function listMine(req,res){const data=await Notification.find({user:req.user._id}).sort({createdAt:-1}).limit(100);res.json({data});}
export async function markRead(req,res){const n=await Notification.findOneAndUpdate({_id:req.params.id,user:req.user._id},{isRead:true},{new:true});if(!n)return res.status(404).json({message:'Notification not found'});res.json({data:n});}
export async function markAll(req,res){await Notification.updateMany({user:req.user._id,isRead:false},{isRead:true});res.json({message:'All notifications marked as read'});}
