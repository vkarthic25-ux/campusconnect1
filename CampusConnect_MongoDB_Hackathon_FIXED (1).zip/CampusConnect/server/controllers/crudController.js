import Achievement from '../models/Achievement.js';
import Club from '../models/Club.js';
import Event from '../models/Event.js';
import Announcement from '../models/Announcement.js';
import Discussion from '../models/Discussion.js';
import User from '../models/User.js';
import Notification from '../models/Notification.js';
const map={achievements:Achievement,clubs:Club,events:Event,announcements:Announcement,discussions:Discussion,users:User};
const isAdmin=req=>req.user.role==='super_admin';
const canManageClub=(req,club)=>isAdmin(req)||req.user.role==='club_admin'&&((club.clubAdmins||[]).some(x=>x.toString()===req.user._id.toString())||club.incharge?.toString()===req.user._id.toString());
const canManageEvent=async(req,event)=>{if(isAdmin(req))return true;if(req.user.role!=='club_admin')return false;const club=event.club?await Club.findById(event.club):null;return !!club&&canManageClub(req,club);};
const createNotification=async(user,title,message,type='system')=>{try{if(user)await Notification.create({user,title,message,type,isRead:false});}catch(e){console.error('notification:',e.message);}};
export async function list(req,res){try{const resource=req.params.resource;if(resource==='users'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can view users'});const M=map[resource];if(!M)return res.status(404).json({message:'Resource not found'});let q=M.find();
if(resource==='achievements')q=q.populate('user','name email profileImage department year');
if(resource==='clubs')q=q.populate('incharge','name email profileImage department year').populate('clubAdmins','name email profileImage department year').populate('members','name email profileImage department year');
if(resource==='events')q=q.populate('club','name logo banner category').populate('createdBy','name profileImage role').populate('facultyCoordinator','name email profileImage department').populate('registrations','name profileImage email');
if(resource==='announcements')q=q.populate('createdBy','name profileImage role');
if(resource==='discussions')q=q.populate('author','name profileImage').populate('comments.user','name profileImage');
if(resource==='users')q=q.select('-password');
const data=await q.sort({createdAt:-1}).limit(200);res.json({data});
}catch(e){res.status(500).json({message:e.message});}}
export async function getOne(req,res){try{const resource=req.params.resource;const M=map[resource];if(!M)return res.status(404).json({message:'Resource not found'});let q=M.findById(req.params.id);
if(resource==='clubs')q=q.populate('incharge','name email profileImage department year').populate('clubAdmins','name email profileImage department year').populate('members','name email profileImage department year').populate('memberApplications.user','name email profileImage department year');
if(resource==='events')q=q.populate('club','name logo banner category').populate('createdBy','name profileImage role').populate('facultyCoordinator','name email profileImage department').populate('registrations','name profileImage email').populate('registrationDetails.user','name email profileImage department year');
if(resource==='achievements')q=q.populate('user','name email profileImage');
if(resource==='announcements')q=q.populate('createdBy','name profileImage role');
if(resource==='discussions')q=q.populate('author','name profileImage').populate('comments.user','name profileImage');
const doc=await q;if(!doc)return res.status(404).json({message:'Not found'});res.json({data:doc});
}catch(e){res.status(500).json({message:e.message});}}
export async function create(req,res){try{const resource=req.params.resource;
if(resource==='users'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can create users'});
if(resource==='clubs'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can create clubs'});
if(resource==='events'&&!['super_admin','club_admin','faculty'].includes(req.user.role))return res.status(403).json({message:'You cannot create events'});
if(resource==='announcements'&&!['super_admin','club_admin','faculty'].includes(req.user.role))return res.status(403).json({message:'You cannot create announcements'});
if(resource==='achievements'&&req.user.role!=='student')return res.status(403).json({message:'Only student accounts can add achievements'});
const M=map[resource];if(!M)return res.status(404).json({message:'Resource not found'});let body={...req.body};
if(resource==='achievements')body.user=req.user._id;
if(resource==='announcements')body.createdBy=req.user._id;
if(resource==='discussions')body.author=req.user._id;
if(resource==='events'){body.createdBy=req.user._id;if(req.user.role==='club_admin'){if(!body.club)return res.status(400).json({message:'Select your club'});const club=await Club.findById(body.club);if(!club||!canManageClub(req,club))return res.status(403).json({message:'You can only create events for your assigned club'});}}
if(resource==='users'&&body.password)body.password=body.password;
const doc=await M.create(body);res.status(201).json({message:'Created successfully',data:doc});
}catch(e){res.status(400).json({message:e.message});}}
export async function update(req,res){try{const resource=req.params.resource;const M=map[resource];if(!M)return res.status(404).json({message:'Resource not found'});const doc=await M.findById(req.params.id);if(!doc)return res.status(404).json({message:'Not found'});
if(resource==='users'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can manage users'});
if(resource==='clubs'&&!canManageClub(req,doc))return res.status(403).json({message:'You can only update your assigned club'});
if(resource==='events'&&!(await canManageEvent(req,doc)))return res.status(403).json({message:'You can only update your club events'});
if(resource==='announcements'&&!isAdmin(req)&&doc.createdBy?.toString()!==req.user._id.toString())return res.status(403).json({message:'You can only update your announcements'});
if(resource==='achievements'&&doc.user?.toString()!==req.user._id.toString()&&!isAdmin(req))return res.status(403).json({message:'You can only update your achievement'});
if(resource==='discussions'&&doc.author?.toString()!==req.user._id.toString()&&!isAdmin(req))return res.status(403).json({message:'You can only update your discussion'});
Object.assign(doc,req.body);await doc.save();res.json({message:'Updated successfully',data:doc});
}catch(e){res.status(400).json({message:e.message});}}
export async function remove(req,res){try{const resource=req.params.resource;const M=map[resource];if(!M)return res.status(404).json({message:'Resource not found'});const doc=await M.findById(req.params.id);if(!doc)return res.status(404).json({message:'Not found'});
if(resource==='users'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can delete users'});
if(resource==='clubs'&&!isAdmin(req))return res.status(403).json({message:'Only super admin can delete clubs'});
if(resource==='events'&&!(await canManageEvent(req,doc)))return res.status(403).json({message:'You can only delete your club events'});
if(resource==='announcements'&&!isAdmin(req)&&doc.createdBy?.toString()!==req.user._id.toString())return res.status(403).json({message:'You can only delete your announcements'});
if(resource==='achievements'&&doc.user?.toString()!==req.user._id.toString()&&!isAdmin(req))return res.status(403).json({message:'You can only delete your achievement'});
if(resource==='discussions'&&doc.author?.toString()!==req.user._id.toString()&&!isAdmin(req))return res.status(403).json({message:'You can only delete your discussion'});
await doc.deleteOne();res.json({message:'Deleted successfully'});
}catch(e){res.status(400).json({message:e.message});}}
export async function joinClub(req,res){try{const club=await Club.findById(req.params.id);if(!club)return res.status(404).json({message:'Club not found'});
const {studentId='',phone='',department='',year='',interests='',reason=''}=req.body||{};
if(!studentId||!phone||!department||!year||!reason)return res.status(400).json({message:'Student ID, phone, department, year and reason for joining are required'});
const uid=req.user._id.toString();
const already=club.members.some(x=>x.toString()===uid);
if(already){const item=club.memberApplications.find(x=>x.user.toString()===uid);if(item){Object.assign(item,{studentId,phone,department,year,interests,reason});await club.save();}return res.json({message:'Your club membership details were updated',data:club});}
club.members.push(req.user._id);club.memberApplications.push({user:req.user._id,studentId,phone,department,year,interests,reason,status:'approved'});await club.save();
await createNotification(req.user._id,'Club membership confirmed',`You joined ${club.name} successfully.`,'club');
const recipients=[...(club.clubAdmins||[]),club.incharge].filter(Boolean).map(x=>x.toString()).filter(x=>x!==uid);for(const id of [...new Set(recipients)])await createNotification(id,'New club member',`${req.user.name} joined ${club.name}.`,'club');
res.json({message:'Club membership confirmed successfully',data:club});
}catch(e){res.status(400).json({message:e.message});}}
export async function registerEvent(req,res){try{const event=await Event.findById(req.params.id);if(!event)return res.status(404).json({message:'Event not found'});
const {name='',email='',phone='',studentId='',department='',year='',purpose=''}=req.body||{};
if(!name||!email||!phone||!studentId||!department||!year)return res.status(400).json({message:'Name, email, phone, student ID, department and year are required'});
if(event.maxParticipants&&event.registrations.length>=event.maxParticipants)return res.status(400).json({message:'Event capacity is full'});
const uid=req.user._id.toString();if(event.registrations.some(x=>x.toString()===uid))return res.status(409).json({message:'You are already registered for this event'});
event.registrations.push(req.user._id);event.registrationDetails.push({user:req.user._id,name,email,phone,studentId,department,year,purpose});await event.save();
await createNotification(req.user._id,'Event registration confirmed',`You are registered for ${event.title}.`,'event');
res.json({message:'Event registration confirmed successfully',data:event});
}catch(e){res.status(400).json({message:e.message});}}
export async function addComment(req,res){try{const d=await Discussion.findById(req.params.id);if(!d)return res.status(404).json({message:'Discussion not found'});if(!req.body.content?.trim())return res.status(400).json({message:'Comment is required'});d.comments.push({user:req.user._id,content:req.body.content.trim()});await d.save();const data=await Discussion.findById(d._id).populate('author','name profileImage').populate('comments.user','name profileImage');res.json({message:'Comment added',data});}catch(e){res.status(400).json({message:e.message});}}
export async function stats(req,res){try{const [users,clubs,events,announcements,achievements,discussions]=await Promise.all([User.countDocuments(),Club.countDocuments(),Event.countDocuments(),Announcement.countDocuments(),Achievement.countDocuments(),Discussion.countDocuments()]);res.json({data:{users,clubs,events,announcements,achievements,discussions}});}catch(e){res.status(500).json({message:e.message});}}
