import mongoose from 'mongoose';
const userSchema=new mongoose.Schema({
  name:{type:String,required:true,trim:true},
  email:{type:String,required:true,unique:true,lowercase:true,trim:true},
  password:{type:String,required:true,minlength:8},
  role:{type:String,enum:['student','faculty','club_admin','super_admin'],default:'student'},
  profileImage:{type:String,default:''},
  phone:{type:String,default:''},
  studentId:{type:String,default:''},
  department:{type:String,default:''},
  year:{type:String,default:''},
  bio:{type:String,default:''},
  interests:{type:[String],default:[]},
  skills:{type:[String],default:[]},
  isActive:{type:Boolean,default:true},
  isVerified:{type:Boolean,default:true}
},{timestamps:true});
export default mongoose.model('User',userSchema);
