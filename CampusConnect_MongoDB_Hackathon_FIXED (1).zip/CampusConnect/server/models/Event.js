import mongoose from 'mongoose';
const registrationDetailSchema=new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
  name:{type:String,default:''},
  email:{type:String,default:''},
  phone:{type:String,default:''},
  studentId:{type:String,default:''},
  department:{type:String,default:''},
  year:{type:String,default:''},
  purpose:{type:String,default:''},
  registeredAt:{type:Date,default:Date.now}
},{_id:true});
const schema=new mongoose.Schema({
  title:{type:String,required:true,trim:true},
  description:{type:String,default:''},
  category:{type:String,default:'General'},
  banner:{type:String,default:''},
  date:{type:Date,required:true},
  startTime:{type:String,default:''},
  endTime:{type:String,default:''},
  venue:{type:String,default:''},
  club:{type:mongoose.Schema.Types.ObjectId,ref:'Club'},
  createdBy:{type:mongoose.Schema.Types.ObjectId,ref:'User'},
  facultyCoordinator:{type:mongoose.Schema.Types.ObjectId,ref:'User'},
  maxParticipants:{type:Number,default:0},
  registrations:[{type:mongoose.Schema.Types.ObjectId,ref:'User'}],
  registrationDetails:{type:[registrationDetailSchema],default:[]}
},{timestamps:true});
export default mongoose.model('Event',schema);
