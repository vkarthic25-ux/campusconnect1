import mongoose from 'mongoose';
const memberApplicationSchema=new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
  studentId:{type:String,default:''},
  phone:{type:String,default:''},
  department:{type:String,default:''},
  year:{type:String,default:''},
  interests:{type:String,default:''},
  reason:{type:String,default:''},
  joinedAt:{type:Date,default:Date.now},
  status:{type:String,enum:['pending','approved','rejected'],default:'approved'}
},{_id:true});
const schema=new mongoose.Schema({
  name:{type:String,required:true,trim:true},
  code:{type:String,default:''},
  description:{type:String,default:''},
  category:{type:String,default:'General'},
  logo:{type:String,default:''},
  coverImage:{type:String,default:''},
  banner:{type:String,default:''},
  objectives:{type:[String],default:[]},
  activities:{type:[String],default:[]},
  incharge:{type:mongoose.Schema.Types.ObjectId,ref:'User'},
  clubAdmins:[{type:mongoose.Schema.Types.ObjectId,ref:'User'}],
  members:[{type:mongoose.Schema.Types.ObjectId,ref:'User'}],
  memberApplications:{type:[memberApplicationSchema],default:[]}
},{timestamps:true});
export default mongoose.model('Club',schema);
