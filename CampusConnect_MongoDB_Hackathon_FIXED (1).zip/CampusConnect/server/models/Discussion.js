import mongoose from 'mongoose';
const schema=new mongoose.Schema({title:{type:String,required:true},content:{type:String,required:true},author:{type:mongoose.Schema.Types.ObjectId,ref:'User'},comments:[{user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},content:String,createdAt:{type:Date,default:Date.now}}]},{timestamps:true});
export default mongoose.model('Discussion',schema);
